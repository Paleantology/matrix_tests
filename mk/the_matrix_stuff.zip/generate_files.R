library(stringr)
library(comprehenr)
library(tools)
library(Revticulate)

#Function for parsing ranges split by '-' into integer vectors
splitToIntRange <- function(nums){
  
  if(!str_detect(nums, "-")){
    return(as.integer(nums))
  }
  
  
  startEnd <- as.integer(unlist(str_split(nums, "-")))
  return(c(startEnd[1]:startEnd[2]))

}
  
#function to get integers from an string  
getNums <- function(numString){
  
  numString <- paste(numString, " ")
  
  broken <- str_split(numString, pattern = " |,")
  
  out <- suppressWarnings(unlist(broken[str_detect(pattern = ".+[0-9]+.+", string = broken)]))
  
  allNums <- suppressWarnings(unlist(lapply(out, splitToIntRange)))
  
  allNums <- allNums[!is.na(allNums)]
  return(allNums)
  
}

#get total number of characters from the dataset
fetchNCHARS <- function(file){
  grepper <- str_extract(readLines(file), "NCHAR=.+;")
  grepper <- grepper[!is.na(grepper)]
  
  grepper <- str_remove_all(grepper, ";")
  
  return(getNums(stripToInts(grepper)))
}

#function to remove all non-integer or integer range values from a string
stripToInts <- function(inp) str_squish(str_remove_all(inp, "[~|!|@|#|$|%|^|&|*|(|)|{|}|_|+|:|\"|<|>|?|,|.|/|;|\'|[|]|=|]|[A-Za-z]|\\t|\\a|\\e|\\f|\\n|\\r"))

#function to get deftype of file
deftype <- function(file) grep("DEFTYPE=", readLines(file), value = TRUE)

#read in Mk_parted.Rev
Mk_parted <- readLines("scripts/mK_parted_seed_final.Rev")

#read in mcmc_partitioned
mcmc_partioned <- readLines("scripts/mcmc_partitioned.Rev")

#read in mcmc_unpartitioned
mcmc_unpartitioned <- readLines("scripts/mcmc_unpartitioned.Rev")

#get list of totally ordered datasets
ords <- to_vec(
  for(i in list.files("nexus/", full.names = TRUE)){
    if(any(str_detect(readLines(i), pattern = "DEFTYPE=ord")))
      i
  }
)


#get files with DNA format to be excluded
withDNA <- to_vec(
  for(i in list.files("nexus/", full.names = TRUE)){
    if(any(str_detect(readLines(i), pattern = "DATATYPE=DNA")))
      i
  }
)

withMultpleSets <- to_vec(
  for(file in list.files("nexus/", full.names = T)){
    if(length(fetchNCHARS(file)) > 1)
      badFiles <- unique(c(badFiles, file))
  }
)

multiSteps <- to_vec(
  for(i in list.files("nexus/", full.names = TRUE)){
    if(any(str_detect(readLines(i), pattern = "step_")))
      i   
  }
)

cat(c("\n\n----These files have multiple ordered steps----\n\n", multiSteps, "\n\n----These files have multiple datasets----\n\n", withMultpleSets, "\n\n----These files have weird genetic formatting----\n\n", withDNA), sep = "\n", file = "C://Users/caleb/OneDrive/Desktop/ManualFiles.txt")





badFiles <- unique(c(withDNA, withMultpleSets, multiSteps))


for(file in list.files("nexus/", full.names = TRUE)){
  if(!file %in% badFiles){

    localParted <- Mk_parted

    #get deftype for the dataset
    
    
    #get ordered and unordered characters from file
    line <- unlist(str_split(string = grep("unord:|ord:", readLines(file), value = T), pattern = ","))

    #get unordered values
    unord <- grep("unord:", line, value = T)
    unordChars <- getNums(stripToInts(unord))

    #get ordered values
    if(file %in% ords)
    {
      ordChars <- c(1:fetchNCHARS(file))
    }
    else
    {
      ord <- grep("[^(un)](ord:)", line, value = T)
      ordChars <- getNums(stripToInts(ord))
    }
    
    #insert un-ordered values and ordered values into proper places in mK_parted
    localParted <- str_replace(localParted, "@1", replacement = paste(ordChars, collapse = ", "))
    localParted <- str_replace(localParted, "@2", replacement = paste(unordChars, collapse = ", "))
    
    
    mk_parted_name <- "C://Users/caleb/OneDrive/Desktop/mK_parteds/mK_parted_" %+% file_path_sans_ext(basename(file)) %+% ".Rev"
    #create mK_parted files  
    cat(localParted, sep = "\n", file = mk_parted_name, append = FALSE)
    
    
    #create mcmc_partitioned files
    local_mcmc_partitioned <- mcmc_partioned
    local_mcmc_partitioned <- str_replace(local_mcmc_partitioned, "\"matrix\"", replacement = "\"../../nexus/" %+% basename(file) %+% "\"")
    local_mcmc_partitioned <- str_replace(local_mcmc_partitioned, "@1", replacement = basename(mk_parted_name))
    cat(local_mcmc_partitioned, sep = "\n", file = "C://Users/caleb/OneDrive/Desktop/mcmc_partition/mcmc_partitioned_" %+% file_path_sans_ext(basename(file)) %+% ".Rev", append = FALSE)
    
    #create mcmc_unpartitioned files
    local_mcmc_unpartitioned <- mcmc_unpartitioned
    local_mcmc_unpartitioned <- str_replace(local_mcmc_partitioned, "\"file\"", replacement = "\"../../nexus/" %+% basename(file) %+% "\"")
    cat(local_mcmc_unpartitioned, sep = "\n", file = "C://Users/caleb/OneDrive/Desktop/mcmc_unpartition/mcmc_unpartitioned_" %+% file_path_sans_ext(basename(file)) %+% ".Rev", append = FALSE)


  }
}










